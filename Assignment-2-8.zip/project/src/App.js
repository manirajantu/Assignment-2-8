// import logo from './logo.svg';

import './App.css';
import Parent from './Parent';

function App() {
  return (
    <Parent></Parent>
  );
}

export default App;
