
import React from "react";
import ReactDOM from "react-dom";

import lightOn from "./assets/images/light-on.png";
import lightOff from "./assets/images/light-off.png";



class Parent extends React.Component {
  constructor(props) {
    super(props);
    this.switchImage = this.switchImage.bind(this);
    this.state = {
      currentImage: 0,
        images: [
        lightOn,
        lightOff,
      ]
    };
  }

  switchImage() {
    if (this.state.currentImage < this.state.images.length - 1) {
      this.setState({
        currentImage: this.state.currentImage + 1
      });
    } else {
      this.setState({
        currentImage: 0
      });
    }
    return this.currentImage;
  }

  componentDidMount() {
    setInterval(this.switchImage, 1000);
  }

  render() {
    return (
      <div className="slideshow-container">
        <img
          src={this.state.images[this.state.currentImage]}
        />
        <button onClick={this.switchImage}>Toggle</button>
      </div>
      

      
    );
  }
}







// class Parent extends React.Component {
//   constructor() {
//     super();
//     this.state = {
//       isLightOn: false,
//     };

//     this.handleToggle = this.handleToggle.bind(this);
//   }

//   handleToggle() {
//     this.setState({ isLightOn: !this.state.isLightOn });
//   }

//   render() {
//     return (
//       <>
//         {
//             // This is conditional rendering
//             this.state.isLightOn && <img src={lightOn} />
//         }

//         {
//             !this.state.isLightOn && <img src={lightOff} />
//         }

//         <button onClick={this.handleToggle}>Toggle</button>
//       </>
//     );
//   }
// }







const rootElement = document.getElementById("root");
ReactDOM.render(<Parent />, rootElement);
export default Parent;
